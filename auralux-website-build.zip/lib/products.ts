export interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice: number;
  image: string;
  color: string;
  batteryLife: string;
  features: string[];
  description: string;
  rating: number;
}

export const products: Product[] = [
  {
    id: 1,
    name: "Auralux Pro X",
    price: 199,
    originalPrice: 249,
    image: "/images/product-1.jpg",
    color: "Midnight Black",
    batteryLife: "36 hours",
    features: ["ANC", "Bluetooth 5.3", "IPX5", "Fast Charge"],
    description:
      "Our flagship earbuds with studio-grade sound and advanced noise cancellation for the ultimate listening experience.",
    rating: 4.9,
  },
  {
    id: 2,
    name: "Auralux Air",
    price: 149,
    originalPrice: 179,
    image: "/images/product-2.jpg",
    color: "Pearl White",
    batteryLife: "30 hours",
    features: ["ANC", "Bluetooth 5.2", "IPX4", "Wireless Charge"],
    description:
      "Featherlight design with crystal-clear audio and adaptive noise cancellation for all-day comfort.",
    rating: 4.7,
  },
  {
    id: 3,
    name: "Auralux Sport",
    price: 129,
    originalPrice: 159,
    image: "/images/product-3.jpg",
    color: "Ocean Blue",
    batteryLife: "28 hours",
    features: ["Transparency Mode", "Bluetooth 5.3", "IPX7", "Ear Detection"],
    description:
      "Built for athletes with secure fit, sweat resistance, and pumping bass to fuel your workouts.",
    rating: 4.8,
  },
  {
    id: 4,
    name: "Auralux Elite",
    price: 249,
    originalPrice: 299,
    image: "/images/product-4.jpg",
    color: "Emerald Green",
    batteryLife: "40 hours",
    features: ["ANC", "Bluetooth 5.3", "IPX6", "Hi-Res Audio"],
    description:
      "Audiophile-grade earbuds with LDAC support and Hi-Res certification for the most discerning listeners.",
    rating: 5.0,
  },
  {
    id: 5,
    name: "Auralux Lite",
    price: 89,
    originalPrice: 109,
    image: "/images/product-5.jpg",
    color: "Titanium Silver",
    batteryLife: "24 hours",
    features: ["ENC", "Bluetooth 5.1", "IPX4", "Touch Control"],
    description:
      "Premium sound at an accessible price. Perfect for everyday listening with environmental noise cancellation.",
    rating: 4.5,
  },
  {
    id: 6,
    name: "Auralux Bass+",
    price: 169,
    originalPrice: 199,
    image: "/images/product-6.jpg",
    color: "Crimson Red",
    batteryLife: "32 hours",
    features: ["ANC", "Bluetooth 5.2", "IPX5", "Extra Bass"],
    description:
      "For bass lovers. Deep, thundering low-end with precision mids and sparkling highs.",
    rating: 4.8,
  },
];
