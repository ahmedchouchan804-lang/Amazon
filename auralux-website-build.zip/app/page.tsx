"use client";

import { CartProvider } from "@/lib/cart-context";
import { Navbar } from "@/components/navbar";
import { Hero } from "@/components/hero";
import { ProductSection } from "@/components/product-section";
import { FeaturesSection } from "@/components/features-section";
import { CartSidebar } from "@/components/cart-sidebar";
import { Footer } from "@/components/footer";

export default function HomePage() {
  return (
    <CartProvider>
      <Navbar />
      <main>
        <Hero />
        <ProductSection />
        <FeaturesSection />
      </main>
      <Footer />
      <CartSidebar />
    </CartProvider>
  );
}
