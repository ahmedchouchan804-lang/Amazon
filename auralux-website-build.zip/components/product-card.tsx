"use client";

import { useState } from "react";
import {
  ShieldCheck,
  Battery,
  Bluetooth,
  Droplets,
  Star,
  ShoppingCart,
  Check,
} from "lucide-react";
import type { Product } from "@/lib/products";
import { useCart } from "@/lib/cart-context";

const featureIcons: Record<string, typeof ShieldCheck> = {
  ANC: ShieldCheck,
  ENC: ShieldCheck,
  "Transparency Mode": ShieldCheck,
  "Bluetooth 5.1": Bluetooth,
  "Bluetooth 5.2": Bluetooth,
  "Bluetooth 5.3": Bluetooth,
  IPX4: Droplets,
  IPX5: Droplets,
  IPX6: Droplets,
  IPX7: Droplets,
  "Fast Charge": Battery,
  "Wireless Charge": Battery,
  "Hi-Res Audio": Battery,
  "Ear Detection": Battery,
  "Touch Control": Battery,
  "Extra Bass": Battery,
};

export function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useCart();
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    addToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <div className="group relative rounded-xl glass overflow-hidden transition-all duration-300 hover:scale-[1.02] hover:shadow-lg hover:shadow-primary/5">
      {/* Discount badge */}
      {product.originalPrice > product.price && (
        <div className="absolute left-3 top-3 z-10 rounded-md bg-primary px-2 py-0.5 text-xs font-bold text-primary-foreground">
          -
          {Math.round(
            ((product.originalPrice - product.price) / product.originalPrice) *
              100
          )}
          %
        </div>
      )}

      {/* Image */}
      <div className="relative aspect-square overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-card/80 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      </div>

      {/* Content */}
      <div className="p-5">
        {/* Name and rating */}
        <div className="flex items-start justify-between gap-2">
          <h3 className="text-lg font-semibold text-foreground">
            {product.name}
          </h3>
          <div className="flex items-center gap-1 shrink-0">
            <Star className="h-3.5 w-3.5 fill-primary text-primary" />
            <span className="text-xs font-medium text-foreground">
              {product.rating}
            </span>
          </div>
        </div>

        <p className="mt-1 text-xs text-muted-foreground">{product.color}</p>

        <p className="mt-2 text-sm leading-relaxed text-muted-foreground line-clamp-2">
          {product.description}
        </p>

        {/* Features */}
        <div className="mt-3 flex flex-wrap gap-1.5">
          {product.features.map((feature) => {
            const Icon = featureIcons[feature] || ShieldCheck;
            return (
              <span
                key={feature}
                className="inline-flex items-center gap-1 rounded-md bg-secondary/60 px-2 py-1 text-[10px] font-medium text-muted-foreground"
              >
                <Icon className="h-3 w-3 text-primary" />
                {feature}
              </span>
            );
          })}
        </div>

        {/* Battery */}
        <div className="mt-3 flex items-center gap-1 text-xs text-muted-foreground">
          <Battery className="h-3.5 w-3.5 text-primary" />
          {product.batteryLife} battery life
        </div>

        {/* Price and CTA */}
        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <span className="text-xl font-bold text-foreground">
              ${product.price}
            </span>
            {product.originalPrice > product.price && (
              <span className="text-sm text-muted-foreground line-through">
                ${product.originalPrice}
              </span>
            )}
          </div>
          <button
            onClick={handleAdd}
            disabled={added}
            className={`inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-medium transition-all ${
              added
                ? "bg-green-500/20 text-green-400"
                : "bg-primary text-primary-foreground hover:opacity-90"
            }`}
          >
            {added ? (
              <>
                <Check className="h-4 w-4" />
                Added
              </>
            ) : (
              <>
                <ShoppingCart className="h-4 w-4" />
                Add to Cart
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
