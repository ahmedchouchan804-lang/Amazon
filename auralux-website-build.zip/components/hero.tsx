"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ChevronDown } from "lucide-react";

export function Hero() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section className="relative flex min-h-screen items-center justify-center overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src="/images/hero-earbuds.jpg"
          alt="Premium wireless earbuds by Auralux"
          className="h-full w-full object-cover opacity-50"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-5xl px-4 text-center sm:px-6 lg:px-8">
        <div
          className={`transition-all duration-1000 ease-out ${
            isVisible
              ? "opacity-100 translate-y-0"
              : "opacity-0 translate-y-8"
          }`}
        >
          <p className="mb-4 text-sm font-medium uppercase tracking-[0.3em] text-primary">
            Premium Wireless Audio
          </p>
          <h1 className="text-balance text-4xl font-bold leading-tight tracking-tight text-foreground sm:text-6xl lg:text-7xl">
            Feel the Sound.
            <br />
            <span className="text-primary">Love the Silence.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg leading-relaxed text-muted-foreground sm:text-xl">
            Experience unparalleled audio clarity with active noise cancellation,
            deep bass, and all-day comfort. Crafted for those who refuse to
            compromise.
          </p>
          <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
            <a
              href="#products"
              className="inline-flex items-center rounded-lg bg-primary px-8 py-3.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 hover:scale-[1.02]"
            >
              Shop Now
            </a>
            <Link
              href="/login"
              className="inline-flex items-center rounded-lg border border-border px-8 py-3.5 text-sm font-semibold text-foreground transition-all hover:bg-secondary"
            >
              Login
            </Link>
            <Link
              href="/signup"
              className="inline-flex items-center rounded-lg border border-primary/30 px-8 py-3.5 text-sm font-semibold text-primary transition-all hover:bg-primary/10"
            >
              Sign Up
            </Link>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <a
        href="#products"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce text-muted-foreground transition-colors hover:text-primary"
        aria-label="Scroll to products"
      >
        <ChevronDown className="h-6 w-6" />
      </a>
    </section>
  );
}
