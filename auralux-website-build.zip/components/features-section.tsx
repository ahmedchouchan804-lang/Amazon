"use client";

import { useEffect, useRef, useState } from "react";
import { Volume2, ShieldOff, Zap, Heart } from "lucide-react";

const features = [
  {
    icon: Volume2,
    title: "Deep Bass Sound",
    description:
      "Custom 12mm drivers deliver rich, immersive bass that you can feel in every beat and note.",
  },
  {
    icon: ShieldOff,
    title: "Noise Cancellation",
    description:
      "Advanced ANC technology blocks out the world so you can focus on what matters most.",
  },
  {
    icon: Zap,
    title: "Fast Charging",
    description:
      "Get 5 hours of playback from just 10 minutes of charging. Never miss a moment.",
  },
  {
    icon: Heart,
    title: "Comfortable Fit",
    description:
      "Ergonomically designed with memory foam tips for all-day comfort that feels custom-made.",
  },
];

export function FeaturesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="text-sm font-medium uppercase tracking-[0.3em] text-primary">
            Why You{"'"}ll Love It
          </p>
          <h2 className="mt-3 text-balance text-3xl font-bold text-foreground sm:text-4xl">
            Engineered for Perfection
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            Every detail has been obsessively refined to deliver an audio
            experience that exceeds expectations.
          </p>
        </div>

        <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, i) => (
            <div
              key={feature.title}
              className={`group rounded-xl glass p-6 text-center transition-all duration-500 hover:scale-[1.03] hover:shadow-lg hover:shadow-primary/5 ${
                isVisible
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: `${i * 150}ms` }}
            >
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-foreground">
                {feature.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
