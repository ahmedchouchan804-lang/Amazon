"use client";

import { useState, useMemo } from "react";
import { SlidersHorizontal, X } from "lucide-react";
import { products } from "@/lib/products";
import { ProductCard } from "@/components/product-card";

const colorOptions = [
  "All",
  "Midnight Black",
  "Pearl White",
  "Ocean Blue",
  "Emerald Green",
  "Titanium Silver",
  "Crimson Red",
];
const batteryOptions = ["All", "24+ hours", "28+ hours", "32+ hours", "36+ hours"];
const priceOptions = ["All", "Under $100", "$100-$150", "$150-$200", "Over $200"];

export function ProductSection() {
  const [colorFilter, setColorFilter] = useState("All");
  const [batteryFilter, setBatteryFilter] = useState("All");
  const [priceFilter, setPriceFilter] = useState("All");
  const [showFilters, setShowFilters] = useState(false);

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (colorFilter !== "All" && p.color !== colorFilter) return false;

      if (batteryFilter !== "All") {
        const hours = parseInt(p.batteryLife);
        const minHours = parseInt(batteryFilter);
        if (hours < minHours) return false;
      }

      if (priceFilter !== "All") {
        if (priceFilter === "Under $100" && p.price >= 100) return false;
        if (priceFilter === "$100-$150" && (p.price < 100 || p.price > 150))
          return false;
        if (priceFilter === "$150-$200" && (p.price < 150 || p.price > 200))
          return false;
        if (priceFilter === "Over $200" && p.price <= 200) return false;
      }

      return true;
    });
  }, [colorFilter, batteryFilter, priceFilter]);

  const hasFilters =
    colorFilter !== "All" || batteryFilter !== "All" || priceFilter !== "All";

  const clearFilters = () => {
    setColorFilter("All");
    setBatteryFilter("All");
    setPriceFilter("All");
  };

  return (
    <section id="products" className="py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="text-sm font-medium uppercase tracking-[0.3em] text-primary">
            Our Collection
          </p>
          <h2 className="mt-3 text-balance text-3xl font-bold text-foreground sm:text-4xl">
            Find Your Perfect Sound
          </h2>
        </div>

        {/* Filters toggle */}
        <div className="mt-10 flex items-center justify-between">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="inline-flex items-center gap-2 rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-secondary"
          >
            <SlidersHorizontal className="h-4 w-4" />
            Filters
          </button>
          {hasFilters && (
            <button
              onClick={clearFilters}
              className="inline-flex items-center gap-1 text-sm text-primary transition-colors hover:text-primary/80"
            >
              <X className="h-3 w-3" />
              Clear all
            </button>
          )}
        </div>

        {/* Filter options */}
        {showFilters && (
          <div className="mt-4 grid gap-4 rounded-xl glass p-6 sm:grid-cols-3 animate-in slide-in-from-top-2">
            <div>
              <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Color
              </label>
              <select
                value={colorFilter}
                onChange={(e) => setColorFilter(e.target.value)}
                className="w-full rounded-lg border border-border bg-secondary/50 px-3 py-2 text-sm text-foreground"
              >
                {colorOptions.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Battery Life
              </label>
              <select
                value={batteryFilter}
                onChange={(e) => setBatteryFilter(e.target.value)}
                className="w-full rounded-lg border border-border bg-secondary/50 px-3 py-2 text-sm text-foreground"
              >
                {batteryOptions.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Price
              </label>
              <select
                value={priceFilter}
                onChange={(e) => setPriceFilter(e.target.value)}
                className="w-full rounded-lg border border-border bg-secondary/50 px-3 py-2 text-sm text-foreground"
              >
                {priceOptions.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}

        {/* Products grid */}
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="mt-16 text-center">
            <p className="text-lg font-medium text-foreground">
              No products match your filters
            </p>
            <button
              onClick={clearFilters}
              className="mt-4 text-sm text-primary transition-colors hover:text-primary/80"
            >
              Clear all filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
